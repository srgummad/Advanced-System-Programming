///////////////////////////////////////////////////
//		CSE-691 Advanced System Programming      //
//		Author: Sricharan Gummadi				 //
//		Project 2 - File Chat Programming        //
///////////////////////////////////////////////////
#define _POSIX_C_SOURCE 199309
#include<stdio.h>
#include<stdlib.h>
#include<sys/time.h>
#include<time.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<errno.h>
#include<string.h>
#include<unistd.h>
#include<signal.h>
#include<sys/signal.h>

#ifndef BUF_SIZE
#define BUF_SIZE 1052
#endif

static volatile sig_atomic_t gotAlarm=0;
static volatile readflag=0;

static void handler(int sig)
{
	
	gotAlarm=1;
	if(readflag==0)
		readflag=1;
	else if(readflag==1)
		readflag=0;	
	alarm(3);
}


int main(int argc,char *argv[])
{

	if(argc<3)
	{
		printf("Usage: %s inputFile outputFile\n",argv[0]);
		exit(EXIT_FAILURE);
	}
	int ifd=open(argv[1],O_RDWR | O_APPEND, S_IRUSR | S_IWUSR);
	if(ifd==-1)
	{
		if(errno == EACCES)
		{
			printf("You don't have the permission to access the file\n");
			exit(EXIT_FAILURE);
		}
		else if(errno==ENOENT)
		{
			printf("Specified file doesn't exist\n");
			exit(EXIT_FAILURE);
		}
		else
			perror("open");
	}
	int ofd=open(argv[2],O_RDWR | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR);
	if(ofd==-1)
	{
		if(errno==EACCES)
		{
			printf("You don't have the permission to access the file\n");
			exit(EXIT_FAILURE);
		}
		else
			perror("open");
	}
	char buf[BUF_SIZE];
	ssize_t numRead;
	struct itimerval itv;
	itv.it_interval.tv_sec=3;
	itv.it_interval.tv_usec=0;
	itv.it_value.tv_sec=3;
	itv.it_value.tv_usec=0;
	int t=0;
	if(setitimer(ITIMER_REAL, &itv, 0)==-1)
		{
			perror("setitimer");
			exit(EXIT_FAILURE);
		}			
	struct sigaction sa;
	sa.sa_flags=0;
	sa.sa_handler= handler;
	if(sigaction(SIGALRM,&sa,NULL)==-1)
	{
		perror("sigaction");
		exit(EXIT_FAILURE);
	}
	
	alarm(3);

	while(1)
	{			
		if(readflag==0)
		{
			char *in_line=NULL;
			size_t line_capacity=0;
			
				int line_size=getline(&in_line,&line_capacity,stdin);
				if(line_size!=-1)
				{
					alarm(3);
					//int line_size=strlen(in_line);
					time_t curtime;
					time(&curtime);
					char *crtime=ctime(&curtime);
					int ln=strlen(crtime)-1;
					if(crtime[ln]=='\n')
						crtime[ln]='\0';
					char *t1=strcat(crtime,", ");
					char *t2=strcat(t1,in_line);
					int len=line_size+28;
					int numWrite=write(ofd,t2,strlen(t2));
					if(numWrite==-1)
					{
						perror("write");
						exit(EXIT_FAILURE);
					}
					t2=NULL;
					t1=NULL;
				}
				free(in_line);
				clearerr(stdin);
		}			
		else if(readflag==1)
		{
			memset(buf,'\0',BUF_SIZE);
			while((read(ifd,buf,BUF_SIZE))>0)
			{
				printf("%s",buf);				
				
			}
		}
		
		clearerr(stdin);
	}
	if(close(ifd)==-1)
	{
			perror("close");
			exit(EXIT_FAILURE);
	}
	if(close(ofd)==-1)
	{
			perror("close");
			exit(EXIT_FAILURE);
	}
}