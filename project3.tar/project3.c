#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include "pthread.h"
#include <sys/sem.h>

#define SHSIZE 1024
#define SHM_KEY 0x1234
#define SEM_KEY 0x5678
#define BUF_SIZE 1024


char *s;
char *r;
int sem_id;
int shmid;
char *shm;

void* producer(void* arg)
{

	int nRead;
	char buf[BUF_SIZE];
	int nbytes=100;
	char *b;
	s=shm;
	
	while(1)
	{
		
		sleep(2);

		struct sembuf sops;
		sops.sem_num=0;
		sops.sem_op=-1;
		sops.sem_flg=0;
		semop(sem_id,&sops,1);
		
		b=(char *)malloc(nbytes+1);
		nRead=getline(&b,&nbytes,stdin);
		if(nRead==-1)
		{
			perror("getline");
			
		}
		if(strcmp(b,"exit\n")==0)
		{
			semctl(sem_id,0,IPC_RMID);
			shmctl(shmid,IPC_RMID,0);
			exit(EXIT_SUCCESS);
		}			
		int pid=getpid();
		
		char str[1024];
		sprintf(str,"process %d sent: %s ",pid,b);
		
		for(s;*s!=0;s++);
		memcpy(s,str,strlen(str));
		r+=strlen(str);
		*r=0;
		sops.sem_op=1;
		semop(sem_id,&sops,1);

	}
	
	return NULL;
}


void* consumer(void* arg)
{
	while(1)
	{		
		while(*r != 0)
		{
			printf("%c",*r);
			r++;
		}
	}
	return NULL;
}


int main(int argc,char *argv[])
{

	int c;
	if(argc>2)
	{
		printf("Usage: %s [-h]",argv[0]);
		exit(EXIT_FAILURE);
	}
	while((c=getopt(argc,argv,":h"))!=-1)
		switch(c)
		{
			case 'h':
				printf("1.	Open atleast 5 terminals and run the program as : %s\n",argv[0]);
				printf("2.	enter the input to terminals and check the message on other terminals\n");
				printf("3.	type 'exit' on each terminal to exit from program\n");
				return 0;
				break;
			default:
				printf("Invalid argument.....Usage: %s [-h]\n",argv[0]);
				abort();
				break;
		}	

	sem_id=semget(SEM_KEY,1,IPC_CREAT | 0666);
	if(sem_id==-1)
	{
		perror("semget");
		exit(EXIT_FAILURE);
	}

	shmid=shmget(SHM_KEY,SHSIZE,IPC_CREAT | 0666);
	if(shmid==-1)
	{
		perror("shmget");
		exit(EXIT_FAILURE);
	}

	shm=shmat(shmid,NULL,0);
	if(shm==(char *)-1)
	{
		perror("shmat");
		exit(EXIT_FAILURE);
	}

	semctl(sem_id,0,SETVAL,1);
	r=shm;

	pthread_t pro_th,con_th;
	int s1=pthread_create(&pro_th,NULL,producer,NULL);
	if(s1!=0)
	{
		perror("pthread_create");
		exit(EXIT_FAILURE);
	}
	

	int s2=pthread_create(&con_th,NULL,consumer,NULL);
	if(s2!=0)
	{
		perror("pthread_create");
		exit(EXIT_FAILURE);
	}


	s1=pthread_join(pro_th,NULL);
	if(s1!=0)
	{
		perror("pthread_join");
		exit(EXIT_FAILURE);
	}

	s2=pthread_join(con_th,NULL);
	if(s2!=0)
	{
		perror("pthread_join");
		exit(EXIT_FAILURE);
	}
	exit(EXIT_SUCCESS);

}