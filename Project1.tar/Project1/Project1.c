#include<stdio.h>
#include<ctype.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<fcntl.h>
#include<getopt.h>
#include<errno.h>
#include<string.h>
#include<pwd.h>
#include<sys/time.h>
#include<utime.h>

#ifndef BUF_SIZE
#define BUF_SIZE 1024
#endif

int main(int argc,char *argv[])
{
	int fflag=0;
	int c;
	ssize_t numRead;
	char buf[BUF_SIZE];
	struct utimbuf utb;
	struct timeval times[2];
	
	if(argc<3)
	{
		printf("Usage: %s [-f] source destination\n",argv[0]);
		return 1;
	}	
	
		
	// checking for -f option
	while((c=getopt(argc,argv,":f"))!=-1)
		switch(c)
		{
			case 'f':
				fflag=1;
				break;
			default:
				printf("Invalid argument.....Usage: argv[0] [-f] source destination\n");
				abort();
				break;
		}	
	if(fflag==1 && argc>4)
	{
		printf("Invaid arguments.....try again\n");
		return 1;
	}
	if(fflag==0 && argc>3)
	{
		printf("Invalid arguments.....try again\n");
		return 1;
	}
	// get the source and destination	
	char *source=argv[optind];
	char *dest=argv[optind+1];
	//printf("source: %s\n",source);
	//printf("destination: %s\n",dest);
	struct stat sb;
	int statno=lstat(source,&sb);
	if(statno == -1)
	{
		perror("stat");
		exit(EXIT_FAILURE);
	}
	
	struct stat info;
	int destno=lstat(dest,&info);
	int nofile=0;	
	if(destno!=0)
	{
		if(errno==ENOENT)
			nofile=1;
		else
			perror("lstat");
	}
	int fd;
	if(destno!=0 && nofile==1)
	{
		//printf("inside....\n");
		fd=open(dest,O_CREAT | O_RDWR | O_TRUNC,S_IRWXU);
		destno=lstat(dest,&info);
	}

	int lflag=0;
	int rfflag=0;
	int dflag=0;
	// checking the destination type
	switch(info.st_mode & S_IFMT)
		{
			case S_IFLNK:	
					lflag=1;
					break;
			case S_IFREG:	
					rfflag=1;					
					break;
			case S_IFDIR:	
					dflag=1;					
					break;			
			default:	
					printf("Invalid file type for use\n");
					break;
		}
	//if destination is file
	if(rfflag==1)
	{		
		if(nofile==0 && fflag==0)
		{
			printf("destination file exists and -f not provided.....exiting\n");
			exit(EXIT_FAILURE);
		}
		fd=open(dest,O_CREAT | O_RDWR | O_TRUNC,S_IRWXU);
		if(fd==-1)
		{
			perror("open");
			exit(EXIT_FAILURE);
		}
		struct stat sb_dest;
		int dest_statno=lstat(dest,&sb_dest);
		if(dest_statno == -1)
		{
			perror("stat");
			exit(EXIT_FAILURE);
		}		
		
		int fd_source=open(source,O_RDONLY);
		if(fd_source==-1)
		{
			perror("open");
			exit(EXIT_FAILURE);
		}		
		
		int own=chown(dest,sb.st_uid,sb.st_gid);
		if(own==-1)
			perror("owner");		
		
		int perm=chmod(dest,sb.st_mode);
		if(perm==-1)
			perror("chmod");	
		
		//write to the file i.e, copy file
		while((numRead=read(fd_source,buf,BUF_SIZE))>0)
		{
			if(write(fd,buf,numRead)!=numRead)
			{
				perror("write");
				exit(EXIT_FAILURE);
			}
		}
		if(numRead==-1)
			perror("read");

		times[0].tv_sec=sb.st_atime;
		times[0].tv_usec=0;
		times[1].tv_sec=sb.st_mtime;
		times[1].tv_usec=0;
		if(lutimes(dest,times)==-1)
			perror("lutimes");


		if(close(fd_source)==-1)
		{
			perror("close");	
			exit(EXIT_FAILURE);		
		}		
		int status=close(fd);
		if(status==-1)
		{
			perror("close");
			exit(EXIT_FAILURE);
		}				
		
	}
	// if destiantion is a directory
	if(dflag==1)
	{
		char *destfile=strcat(dest,source);
		//printf("now destination file is : %s\n",destfile);
		struct stat destsb;
		int deststat=stat(destfile,&destsb);
		int destfl=0;
		if(deststat!=0)
		{
			if(errno==ENOENT)
				destfl=1;
			else
				perror("stat");
		}		
		if(fflag==0 && destfl==0)
		{
			printf("file exists and -f not provided\n");
			exit(EXIT_FAILURE);
		}

		int fd=open(destfile,O_CREAT | O_RDWR | O_TRUNC,S_IRWXU);
		if(fd==-1)
		{
			perror("open");
			exit(EXIT_FAILURE);
		}
		struct stat sb_dest;
		int dest_statno=lstat(dest,&sb_dest);
		if(dest_statno == -1)
		{
			perror("stat");
			exit(EXIT_FAILURE);
		}
		
		//printf("dflag encountered\n");

				

		int fd_source=open(source,O_RDONLY);
		if(fd_source==-1)
		{
			perror("open");
			exit(EXIT_FAILURE);
		}
		
		
		int own=chown(dest,sb.st_uid,sb.st_gid);
		if(own==-1)
			perror("owner");		
		
		int perm=chmod(dest,sb.st_mode);
		if(perm==-1)
			perror("chmod");
		
		//write to the file(copy)
		while((numRead=read(fd_source,buf,BUF_SIZE))>0)
		{
			if(write(fd,buf,numRead)!=numRead)
			{
				perror("write");
				exit(EXIT_FAILURE);
			}
		}
		if(numRead==-1)
			perror("read");

		times[0].tv_sec=sb.st_atime;
		times[0].tv_usec=0;
		times[1].tv_sec=sb.st_mtime;
		times[1].tv_usec=0;
		if(lutimes(dest,times)==-1)
			perror("lutimes");


		if(close(fd_source)==-1)
		{
			perror("close");	
			exit(EXIT_FAILURE);		
		}		
		int status=close(fd);
		if(status==-1)
		{
			perror("close");
			exit(EXIT_FAILURE);
		}	
	}
	return 0;
}
